// This program is a simple command-line calculator in Node js.
// It allows users to perform addition, subtraction, multiplication, and division.
// Users can input multiple numbers, and the program will calculate and display the result.
// Input validation ensures the user enters valid operations and numbers.

// Author: Saifullah Omar
// Date: 01/10/2024

// Import the prompt-sync module to allow synchronous user input from the console
// This module allows us to read input from the command line without the need for asynchronous code.
const prompt = require('prompt-sync')();

// Display program title
console.log("\n*************************************************************************");
console.log("\n                   ***SIMPLE NODE JS MATH CALCULATOR***                  ");
console.log("\n*************************************************************************");
console.log("");  // Print a blank line for spacing

// Define an object called 'operations' that maps operation names (keys) to the functions (values)
// Each function takes two arguments 'a' and 'b' and performs the respective mathematical operation.
const operations = 
{
    add: (a, b) => a + b,         // Function to add two numbers
    subtract: (a, b) => a - b,    // Function to subtract two numbers
    multiply: (a, b) => a * b,    // Function to multiply two numbers
    divide: (a, b) => a / b       // Function to divide two numbers
};

// Main function to handle input, perform the selected operation, and display the result
const main = () => 
{
    // Prompt the user to choose an operation (add, subtract, multiply, divide)
    // The user's input is converted to lowercase to avoid case-sensitive issues (e.g., 'Add' or 'ADD').
    const operation = prompt('Choose an operation: (add, subtract, multiply, divide): ').toLowerCase();
    console.log("");  // Blank line for better formatting

    // Prompt the user to enter numbers, separated by commas
    // The input string is split by commas and converted to an array of numbers using 'map(Number)'
    // 'map(Number)' ensures each element in the array is parsed as a float or integer.
    const numbers = prompt('Enter numbers separated by commas (e.g., 1, 2, 3): ').split(',').map(Number);
    console.log("\n*************************************************************************");
    console.log("");  // Print a blank line for spacing

    // Check if the user entered a valid operation and all inputs are valid numbers
    // - 'operations[operation]' checks if the operation exists in the 'operations' object.
    // - 'numbers.some(isNaN)' checks if any of the numbers entered is not a valid number.
    if (!operations[operation] || numbers.some(isNaN)) 
    {
        // If the operation is invalid or the numbers are not valid, display an error message
        console.log('Invalid operation or numbers.');
        console.log("\n*************************************************************************");
        console.log("");  // Blank line after error message
        return;  // Exit the function early to prevent further execution
    }

    // If the input is valid, apply the chosen operation to the numbers array using the reduce method
    // - The reduce method applies the operation cumulatively from left to right (e.g., (a + b + c)).
    // - For instance, if the operation is 'add', it will sum all the numbers in the array.
    const result = numbers.reduce(operations[operation]);

    // Print the final result to the console
    // The result is displayed in a formatted way for better readability
    console.log(`The RESULT is: ${result}`);
    console.log("");   // Print a blank line for spacing
    console.log("*************************************************************************"); // End Program
};

// Call the main function to run the program when the script is executed
main();
