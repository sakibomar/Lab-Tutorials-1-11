// Import React and ReactDOM for rendering components
import React from 'react';  
import ReactDOM from 'react-dom';  
// Import the CSS file for applying global styles
import './index.css';  
// Import components to render specific functionality
import EmojeeCounter from './emojeeCounters';  // EmojeeCounter component
import HookControlledButtonState from './counter';  // Button state management component
import MoodDisplay from './moodDisplay';  // MoodDisplay component for dynamic mood rendering

// Render components into the DOM
ReactDOM.render(
  // React.StrictMode helps identify potential problems during development
  <React.StrictMode>
    {/* Dynamic mood rendering */}
    <MoodDisplay />
    {/* State management*/}
    <HookControlledButtonState />
    {/* Mood counters for emojis */}
    <EmojeeCounter pic="Love" />
    <EmojeeCounter pic="Sad" />
    <EmojeeCounter pic="Like" />
  </React.StrictMode>,

  // Target the HTML element with id 'root' for rendering
  document.getElementById('root')
);
