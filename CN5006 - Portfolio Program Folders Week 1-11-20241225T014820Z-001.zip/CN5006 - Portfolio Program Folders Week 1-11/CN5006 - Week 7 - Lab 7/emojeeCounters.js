// Import necessary dependencies from React and the image assets for Emojee images.
import React, { useState, useEffect } from "react"; 
import Love from './Love.png';
import Sad from './Sad.png';
import Like from './Like.png';

// Define the EmojeeCounter component which displays an emoji and a count that increments on button click.
function EmojeeCounter(props) {
  // Log the initial 'pic' prop value to the console for debugging purposes.
  console.log("Initial pic is:", props.pic);

  // Declare two state variables:
  // - 'pic' for storing the current emoji image.
  // - 'count' for storing the number of button clicks.
  const [pic, setPic] = useState(Love);  // Default emoji is 'Love'
  const [count, setCount] = useState(0);  // Initial count is set to 0

  // useEffect hook runs when the 'pic' prop changes. 
  // It updates the 'pic' state based on the 'pic' prop.
  useEffect(() => {
    console.log("useEffect called with pic:", props.pic);

    // Based on the value of the 'pic' prop, set the corresponding emoji.
    if (props.pic === "Love") {
      setPic(Love); // Set to Love emoji
    } else if (props.pic === "Like") {
      setPic(Like); // Set to Like emoji
    } else if (props.pic === "Sad") {
      setPic(Sad); // Set to Sad emoji
    }
  }, [props.pic]);  // Dependency array ensures effect runs only when the 'pic' prop changes.

  // Define the ClickHandle function which increments the count when the button is clicked.
  const ClickHandle = () => {
    setCount(prevCount => prevCount + 1);  // Use the previous count to ensure the correct increment
  };

  // Return the JSX structure to render the UI.
  // It includes the emoji image and a button that shows the click count.
  return (
    <div className="App">
      <button onClick={ClickHandle}>
        <img src={pic} alt="Emoji" />  {/* Display the corresponding emoji image */}
        {count}  {/* Display the current count */}
      </button>
    </div>
  );
}

// Export the EmojeeCounter component to be used in other parts of the application.
export default EmojeeCounter;
