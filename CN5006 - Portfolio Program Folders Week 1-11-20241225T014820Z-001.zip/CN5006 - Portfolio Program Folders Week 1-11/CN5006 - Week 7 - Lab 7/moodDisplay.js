// Import necessary dependencies for React components
import React, { useState } from "react";

// Import image assets for each mood; these will be dynamically displayed based on user input
import HappyFace from './Happy.png'; // Path to the image representing a "Happy" mood
import SadFace from './Sad.png';     // Path to the image representing a "Sad" mood
import LikeIcon from './Like.png';  // Path to the image representing a "Like" action

// Define the functional component "MoodDisplay"
function MoodDisplay() {
  /**
   * useState hook to manage component state:
   * - 'input': stores the text entered by the user in the text box
   * - 'image': holds the path to the current image to be displayed in the label
   */
  const [input, setInput] = useState("");
  const [image, setImage] = useState(null);

  /**
   * handleInputChange function:
   * - Triggered on each keystroke in the text box.
   * - Captures the current input value, normalizes it to lowercase, and updates the 'input' state.
   * - Based on the normalized input, sets the corresponding image in the 'image' state.
   * - If the input does not match predefined keywords ("happy", "sad", "like"), it clears the image.
   */
  const handleInputChange = (e) => {
    const text = e.target.value.toLowerCase(); // Normalize input for case-insensitive matching
    setInput(text); // Update the state to reflect the current text box input

    // Match the input text with predefined keywords and assign the corresponding image
    if (text === "happy") {
      setImage(HappyFace); // Set to HappyFace image if input is "happy"
    } else if (text === "sad") {
      setImage(SadFace); // Set to SadFace image if input is "sad"
    } else if (text === "like") {
      setImage(LikeIcon); // Set to LikeIcon image if input is "like"
    } else {
      setImage(null); // Clear the image if input doesn't match any predefined keywords
    }
  };

  /**
   * Render the UI:
   * - Includes a heading, an input box, and a dynamic label for displaying the image.
   * - The image label updates based on the 'image' state, which depends on the input.
   */
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Mood Selector</h1> {/* Title for the application */}

      {/* Input field for user interaction */}
      <input
        type="text" // Defines an input box for text
        placeholder="Type 'Happy', 'Sad', or 'Like'" // Guides the user on valid inputs
        value={input} // Sync the input value with the 'input' state
        onChange={handleInputChange} // Update the state and logic when the user types
        style={{
          padding: "10px", // Add padding for better usability
          fontSize: "16px", // Set font size for readability
          borderRadius: "5px", // Round the corners of the input box
          border: "1px solid #ccc", // Add a light border for clarity
          marginBottom: "20px", // Create space between the input and the label
        }}
      />

      {/* Container for the dynamic label */}
      <div>
        {/* Display the image if a valid mood is matched; otherwise, show a fallback message */}
        {image ? (
          <img
            src={image} // Bind the 'image' state to the image source
            alt={input} // Provide an alternative text based on the input
            style={{ width: "100px", height: "100px" }} // Set consistent size for the image
          />
        ) : (
          <p>No mood selected</p> // Fallback text when input doesn't match predefined keywords
        )}
      </div>
    </div>
  );
}

// Export the MoodDisplay component for use in other parts of the application.
export default MoodDisplay;
