/**
 * index.js
 *
 * This module implements an Express.js application that serves as a RESTful API 
 * for managing student information.
 *
 * Key functionalities include:
 * 
 * - Handling GET requests to serve a greeting message, application information, 
 *   and static HTML forms (e.g., StudentInfo.html).
 * - Fetching student data from a local JSON file (`Student.json`) using dynamic 
 *   endpoints to retrieve specific student information or all student records.
 * - Processing form submissions from `StudentInfo.html`, validating the input, 
 *   and returning the structured data as JSON.
 *
 * This module facilitates communication between the client-side HTML form and 
 * the server, ensuring that user-submitted data is captured, validated, and stored 
 * effectively.
 *
 * @see StudentInfo.html
 * @see Student.json
 *
 * @author Saifullah Omar
 *
 * @version 25/10/24
 */

// Import required modules
const express = require("express"); // Express framework for building RESTful APIs
const fs = require("fs"); // Native file system module for file operations

// Initialize an instance of an Express application
const app = express();

// Middleware configuration
// This middleware parses incoming requests with URL-encoded payloads,
// allowing us to easily access form data in the req.body object.
app.use(express.urlencoded({ extended: true }));

// Route: Root endpoint
// This route serves a basic greeting message for the application.
// It serves as a health check to confirm that the server is running.
app.get('/', (req, res) => {
    res.send("Hello, it is my first express application");
});

// Route: About endpoint
// Provides a brief description of the application, including its purpose
// and the author. Useful for documentation and user guidance.
app.get('/about', (req, res) => {
    res.send("This is a basic express application. CN5006 Lab Session Week 4 prepared by Dr. N. Qazi");
});

// Route: Dynamic endpoint for fetching user-specific book information
// This route captures userId and bookId from the URL parameters and
// responds with the extracted parameters in JSON format.
app.get('/users/:userId/books/:bookId', (req, res) => {
    res.json(req.params); // Return URL parameters as a JSON object for further processing.
});

// Route: Fetch specific student data by ID from a JSON file
// This endpoint reads student information from a local JSON file.
// It extracts the student ID from the request parameters and checks if
// the corresponding student exists in the data.
app.get('/GetStudentid/:id', (req, res) => 
    {
    // Read the student data file asynchronously
    fs.readFile(__dirname + "/Student.json", 'utf8', (err, data) => 
    {
        if (err) 
        {
            // Respond with a 500 error if there's an issue reading the file
            return res.status(500).json({ error: "Error reading student data" });
        }

        // Parse the JSON data to access student records
        const students = JSON.parse(data);
        // Dynamically access the student by ID
        const student = students[`Student${req.params.id}`]; 

        if (student) 
        {
            // If the student is found, return their details
            return res.json(student);
        }

        // If the student is not found, return a 404 response with details
        res.status(404).json({
            status: false,
            Status_Code: 404,
            message: "Student not found",
            requested_at: new Date().toLocaleString(), // Timestamp for the request
            requrl: req.url, // Original request URL
            request_method: req.method, // HTTP method used for the request
            studentdata: null // Indicate that no student data was found
        });
    });
});

// Route: Fetch all students' data from the JSON file
// This endpoint retrieves the entire student dataset, providing an overview
// of all student records stored in the JSON file.
app.get('/GetStudents', (req, res) => {
    // Read the student data file asynchronously
    fs.readFile(__dirname + "/Student.json", 'utf8', (err, data) => {
        if (err) {
            // Respond with a 500 error if there's an issue reading the file
            return res.status(500).json({ error: "Error reading student data" });
        }

        // Parse the JSON data to access the list of students
        const studentData = JSON.parse(data);
        console.log(studentData); // Debugging log to inspect the retrieved data

        // Respond with the full set of student data and metadata
        res.json({
            status: true, // Indicates successful response
            Status_Code: 200, // HTTP status code for success
            requested_at: new Date().toLocaleString(), // Timestamp for the request
            requrl: req.url, // Original request URL
            request_method: req.method, // HTTP method used for the request
            studentdata: studentData // Include the parsed student data
        });
    });
});

// Route: Serve the student information form
// This route serves an HTML file that contains a form for users to input
// student information. It utilizes Express's sendFile method to serve
// the static HTML file from the server's root directory.
app.get('/studentinfo', (req, res) => {
    res.sendFile('StudentInfo.html', { root: __dirname }); // Serve the HTML file
});

// Route: Handle form submission for student information
// This endpoint processes the data submitted from the student information
// form. It extracts the necessary fields from the request body and
// validates the input before responding with the structured data.
app.post('/submit-data', (req, res) => {
    // Destructure required fields from the request body for clarity
    const { firstName, lastName, myAge, gender, Qual } = req.body;
    const name = `${firstName} ${lastName}`; // Construct the full name

    // Validate that all required fields are provided
    if (!name || !myAge || !gender || !Qual) {
        return res.status(400).json({
            status: false,
            message: 'All fields are required', // Inform the client about the missing fields
        });
    }

    // Respond with the submitted form data in a structured format
    res.json({
        status: true, // Indicates successful processing
        message: 'Form Details Submitted Successfully',
        data: { name, age: myAge, gender, qualifications: Qual } // Send a structured response
    });
});

// Start the server on port 5000
app.listen(5000, () => {
    console.log("Server is running on port 5000"); // Log server status upon successful startup
});
