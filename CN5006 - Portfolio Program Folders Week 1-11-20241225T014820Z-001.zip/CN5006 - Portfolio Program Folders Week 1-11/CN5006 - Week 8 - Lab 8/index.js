// Importing the Mongoose library to interact with MongoDB
const mongoose = require('mongoose');

// Importing the Express framework to build the application
const express = require('express');

// Initializing the Express application
const app = express();

// Defining the MongoDB connection string
// 'mongodb://localhost:27017/Week-8' connects to the database named 'Week-8' on the local machine
const MONGO_URI = 'mongodb://localhost:27017/Week-8';

// Connecting to MongoDB using Mongoose with specified options
// 'useUnifiedTopology' uses the latest connection management engine
// 'useNewUrlParser' uses the updated URL string parser to connect to MongoDB
mongoose.connect(MONGO_URI, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
}).catch(err => {
    // Handling errors during the initial connection
    console.error('Error during initial connection:', err);
});

// Getting a reference to the MongoDB connection instance
const db = mongoose.connection;

// Event listener for MongoDB connection errors
db.on('error', function(err) {
    console.log("Error occurred during connection: " + err);
});

// Event listener for a successful MongoDB connection
db.once('connected', function() {
    console.log(`Connected to ${MONGO_URI}`);
});

// Defining a schema for the 'Person' collection
// A schema specifies the structure and rules for documents in the collection
const PersonSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    }, // 'name' field, required type: String
    age: Number, // 'age' field, type: Number
    Gender: String, // 'Gender' field, type: String
    Salary: Number // 'Salary' field, type: Number
});

// Creating a model based on the schema
// The model is named 'modelname' and maps to the 'personCollection' in the database
const person_doc = mongoose.model('modelname', PersonSchema, 'personCollection');

// Creating a new document (record) to be inserted into the 'personCollection'
const doc1 = new person_doc({
    name: 'Alex', // 'name' value for the document
    age: 24, // 'age' value for the document
    Gender: "Male", // 'Gender' value for the document
    Salary: 1999 // 'Salary' value for the document
});

// Saving the document to the database
doc1.save()
    .then((doc1) => {
        // Log success message when the document is saved
        console.log("New Article Has been Added Into Your DataBase.", doc1);
    })
    .catch((err) => {
        // Log any errors that occur while saving the document
        console.error(err);
    });

// Array of multiple documents to be inserted into the 'personCollection'
let manypersons = [{
        name: 'Simon',
        age: 42,
        Gender: "Male",
        Salary: 3456
    },
    {
        name: 'Neesha',
        age: 23,
        Gender: "Female",
        Salary: 1000
    },
    {
        name: 'Mary',
        age: 27,
        Gender: "Female",
        Salary: 5402
    },
    {
        name: 'Mike',
        age: 40,
        Gender: "Male",
        Salary: 4519
    }
];

// Inserting multiple documents into the 'personCollection'
person_doc.insertMany(manypersons)
    .then(function() {
        // Log success message when the data is inserted successfully
        console.log("Data inserted"); // Success
    })
    .catch(function(error) {
        // Log any errors that occur during the insert operation
        console.log(error); // Failure
    });

// Find documents with sorting, field selection, and limit the results to 5.
// This block sorts the documents based on salary in ascending order and returns specific fields only (name, salary, and age).
var givenage = 15;

person_doc.find({
        Gender: "Female",
        age: {
            $gte: givenage
        }
    }) // Find all documents in the collection
    .sort({
        Salary: 1
    }) // Sort documents in ascending order based on Salary
    .select('name Salary age') // Only select 'name', 'Salary', and 'age' fields to return
    .limit(5) // Limit the result to 5 documents
    .exec() // Execute the query to get the results
    .then(docs => {
        console.log("Showing documents sorted by Salary, limited to 5:");
        // Loop through each document and log its age, name, and salary
        docs.forEach(function(doc) {
            console.log(doc.age, doc.name, doc.Salary); // Display age, name, and salary
        });
    })
    .catch(err => {
        // If any error occurs during the query, log the error
        console.error('Error occurred:', err);
    });

var givenage = 15;

// Find documents where Gender is "Female" and age is greater than or equal to givenage.
// Sort the results by Salary in ascending order, select specific fields (name, Salary, age), 
// and limit the results to 5 documents.
person_doc.find({
        Gender: "Female",
        age: {
            $gte: givenage
        }
    }) // Filter documents where Gender is "Female" and age >= givenage
    .sort({
        Salary: 1
    }) // Sort the results by Salary in ascending order (lowest to highest)
    .select('name Salary age') // Only include 'name', 'Salary', and 'age' in the returned documents
    .limit(5) // Limit the number of documents returned to 5
    .exec() // Execute the query and return a promise with the results
    .then(docs => {
        console.log("Showing documents sorted by Salary and Gender, limited to 5:");

        // Iterate through the results and log the name, age, and salary of each document.
        docs.forEach(function(doc) {
            console.log(doc.age, doc.name, doc.Salary); // Log the age, name, and salary of each document
        });
    })
    .catch(err => {
        // If an error occurs during the query, log the error to the console.
        console.error('Error occurred:', err);
    });

// Counting all the documents in the collection.
// The countDocuments() method is used to count all the documents in the collection.
// It doesn't require any filters, so it counts all the documents in the collection.
person_doc.countDocuments()
    // Executes the query to count all documents in the collection
    .exec()
    // Executes the counting operation
    .then(count => {
        // Once the query is executed successfully
        console.log("Total documents Count:", count);
        // Outputs the total number of documents
    })
    .catch(err => {
        // If any error occurs during the execution
        console.error('Error:', err);
        // Outputs the error message
    });

// Using deleteMany to remove documents from the 'personCollection' where the age is greater than or equal to 25
// The $gte operator is used to match documents where the age is greater than or equal to 25
// The exec() function executes the query and returns a promise
person_doc.deleteMany({
        age: {
            $gte: 25
        }
    })
    // Execute the query
    .exec()
    .then(docs => {
        // Log the result, which contains the deleted documents' information
        console.log('Deleted documents are:', docs);
    })
    .catch(function(error) {
        // Log any errors that occur during the delete operation
        console.log(error);
    });

// Updating multiple documents in the 'personCollection' where the Gender is 'Female'
// The update operation sets the Salary to 5555 for all matching documents
// The exec() function executes the update query and returns a promise
person_doc.updateMany({
        Gender: "Female"
    }, {
        $set: {
            Salary: 5555
        }
    })
    // Execute the update query
    .exec() 
    .then(docs => {
        // Log a success message and the result of the update operation
        console.log("Update successful");
        // Contains information about the update operation
        console.log(docs); 
    })
    .catch(function(error) {
        // Log any errors that occur during the update operation
        console.log("Error during update:");
        console.log(error);
    });