import React, { Component, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

/**
* FncDisplayBooks Component
* Parent component that fetches book data and passes it to DisplayData
* Uses functional component pattern with React hooks for state management
* Fetches data using axios and stores it in component state
* @returns {JSX.Element} - Returns DisplayData component with books data
*/
export default function FncDisplayBooks() {
  // Initialize state for books data using useState hook
  // Books array will store fetched data, setBooks function updates the state
  const [Books, setBooks] = useState([]);
  
  // API endpoint URL for fetching books
  const url = "http://localhost:5000/allbooks/"

  /**
   * useEffect hook handles side effects (data fetching)
   * Empty dependency array [] means this effect runs once on component mount
   */
  useEffect(() => {
      // Make GET request to books API endpoint
      axios.get(url)
          .then(res => {
              // On successful response, update Books state with fetched data
              setBooks(res.data)
          })
          .catch(err => {
              // Log error message if request fails
              console.log("error has occured")
          })
  }, []) // Empty dependency array means effect runs only once on mount

  // Render DisplayData component and pass Books state as prop
  return (
      <div>
          <DisplayData Books={Books} />
      </div>
  )
}