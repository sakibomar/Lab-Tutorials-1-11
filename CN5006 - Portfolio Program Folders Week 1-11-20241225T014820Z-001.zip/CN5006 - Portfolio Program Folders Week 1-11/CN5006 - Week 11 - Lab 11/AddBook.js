import React, { useState } from "react";
import axios from 'axios';

/**
 * AddBook - A React component for adding new books to the library system
 * 
 * This component provides a form interface for users to input book details including:
 * - Book title
 * - Author information
 * - Topic/Category selection
 * - Format (Hard Copy or Electronic Copy)
 * - Publication Year
 * 
 * The component uses local state management with useState and makes API calls
 * to persist the data to a backend server.
 */
export default function Book_Form() {
  // Backend API endpoint
  let url = "http://localhost:5000/";

  // Initialize form state with default values
  // Each property corresponds to a form field
  const [state, setState] = useState({
    booktitle: "",     // Stores the book's title
    author: "",        // Stores author name(s)
    formate: "",       // Stores book format (Hard/Electronic Copy)
    Topic: "",         // Stores book category/topic
    PubYear: 1990,     // Stores publication year with default value
  });

  /**
   * Generic change handler for all form inputs
   * Updates the state based on input name and value
   * 
   * @param {Object} e - Event object from form input change
   */
  const handleChange = (e) => {
    const value = e.target.value;
    setState(prevState => ({
      ...prevState,
      [e.target.name]: value,
    }));
  };

  /**
   * Form submission handler
   * Prevents default form submission, constructs book data object,
   * and sends POST request to backend API
   * 
   * @param {Object} e - Form submission event object
   */
  const OnSubmit = (e) => {
    e.preventDefault();
    
    // Create book data object from current state
    const bookdata = {
      booktitle: state.booktitle,
      PubYear: state.PubYear,
      author: state.author,
      Topic: state.Topic,
      formate: state.formate
    };

    // Make API call to add new book
    axios.post(url + "addbooks", bookdata)
      .then(res => console.log(res.data))
      .catch(error => {
        console.error("Error adding book:", error);
      });
  }

  // Render form interface
  return (
    <div style={{marginTop: 10}}>
      <h3>Add Book</h3>
      {/* Main form element with POST method */}
      <form onSubmit={OnSubmit} method="Post">
        {/* Book Title Input Section */}
        <div className="form-group"> 
          <label>Book Title: </label>
          <input 
            className="form-control"
            type="text" 
            name="booktitle"
            value={state.booktitle}
            onChange={handleChange}
          />
        </div>

        {/* Book Authors Input Section */}
        <div className="form-group">
          <label>Book Authors: </label>
          <input  
            className="form-control"
            name="author"
            value={state.author}
            onChange={handleChange}
          />
        </div>

        {/* Book Topic Dropdown Selection */}
        <div className="form-group">
          <label>
            Pick Book topic :{" "}
            <select 
              className="form-control"
              name="Topic" 
              value={state.Topic}
              onChange={handleChange}
            >
              {/* Predefined topic options */}
              <option value="Computer Science">CS</option>
              <option value="Programming">Programming</option>
              <option value="Data Science">Data Science</option>
              <option value="AI">AI</option>
              <option value="Engineering">Engineering</option>
            </select>
          </label>
        </div>

        {/* Book Format Radio Button Selection */}
        <div className="form-group">
          <label>Format: </label>
          {/* Hard Copy option */}
          <div className="form-check form-check-inline">
            <input 
              className="form-check-label"
              type="radio" 
              name="formate" 
              value="Hard Copy"
              checked={state.formate === "Hard Copy"}
              onChange={handleChange} 
            />
            <label className="form-check-label"> Hard Copy </label>
          </div>
          {/* Electronic Copy option */}
          <div className="form-check form-check-inline">
            <input 
              className="form-check-label"
              type="radio"
              name="formate" 
              value="Electronic Copy"
              checked={state.formate === "Electronic Copy"}
              onChange={handleChange}
            />
            <label className="form-check-label"> Electronic Copy</label>
          </div>
        </div>  

        {/* Publication Year Range Slider */}
        <div>
          <label>
            Publication Year (between 1980 and 2025):
            <input
              type="range"
              name="PubYear"
              min="1980"
              max="2025" 
              value={state.PubYear}
              onChange={handleChange} 
            />
          </label>
        </div>
        
        {/* Form Submit Button */}
        <div className="form-group">
          <center>
            <input type="submit" value="Add this book" className="btn btn-primary" />
          </center>                   
        </div>
      </form>
    </div>
  );
}