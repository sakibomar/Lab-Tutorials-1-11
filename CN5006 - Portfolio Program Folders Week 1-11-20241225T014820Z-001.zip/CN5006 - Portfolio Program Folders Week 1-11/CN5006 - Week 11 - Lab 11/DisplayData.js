import { Link } from 'react-router-dom';

/**
* ShowBooks Component
* This is a child component responsible for rendering individual book rows
* @param {Object} props - Component props
* @param {Array} props.TBooks - Array of book objects containing book information
* @returns {JSX.Element} - Returns table rows with book data or a "No Data" message
*/
const ShowBooks = (props) => {
   // Extract TBooks array from props using destructuring 
   const Data = props.TBooks

   // Conditional rendering based on whether data exists
   if (Data.length > 0) {
       return (
           // Map through the array of books to create table rows
           // Each book object is transformed into a table row (tr) element
           Data.map((book, index) => {
               return (
                   <tr>
                       {/* Display book properties in table cells
                           Each td represents a column in the table */}
                       <td>{book.booktitle}</td>  {/* Book title column */}
                       <td>{book.PubYear}</td>    {/* Publication year column */}
                       <td>{book.author}</td>     {/* Author column */}
                       <td>{book.Topic}</td>      {/* Topic/Subject column */}
                       <td>{book.formate}</td>    {/* Format column */}
                       
                       {/* Edit link cell - Creates a route to edit form
                           Uses template literal to construct URL with book ID */}
                       <td>
                           <Link to={"/edit/" + book._id}>Edit</Link>
                       </td>
                       
                       {/* Delete link cell - Creates a route to delete confirmation
                           Uses template literal to construct URL with book ID */}
                       <td>
                           <Link to={"/Delete/" + book._id}>Delete</Link>
                       </td>
                   </tr>
               )
           })
       )
   } else {
       // If no data exists, display a message instead of empty table
       return (<h1>No Data Returned</h1>)
   }
}

/**
* DisplayData Component
* Main parent component that creates the structure for the books table
* @param {Object} props - Component props
* @param {Array} props.Books - Array of book objects to be displayed
* @returns {JSX.Element} - Returns complete table structure with headers and data
*/
export default function DisplayData (props) {
   // Extract Books array from props
   const Books = props.Books
   
   return (
       <div>
           {/* Table title */}
           <h3>Book List</h3>
           
           {/* Table element styled with Bootstrap classes for striped rows and hover effects */}
           <table 
               className="table table-striped"
               class="table table-hover"
               style={{ marginTop: 20 }} // Adds spacing above the table
           >
               {/* Table Header Section defining column headers */}
               <thead>
                   <tr>
                       <th>Book Title</th>
                       <th>Pub Year</th>
                       <th>Auhtor</th>
                       <th>Subject</th>
                       <th>Formate</th>
                   </tr>
               </thead>
               
               {/* Table Body Section - Renders ShowBooks component with Books data */}
               <tbody>
                   <ShowBooks TBooks={Books} />
               </tbody>
           </table>
       </div>
   )
}