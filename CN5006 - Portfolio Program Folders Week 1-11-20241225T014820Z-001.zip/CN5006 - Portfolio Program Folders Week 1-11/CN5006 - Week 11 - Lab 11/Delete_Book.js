/**
 * DeleteBook Component
 * Handles the deletion of a book and automatically refreshes the book list
 * 
 * Flow:
 * 1. Deletes specified book using ID from URL parameters
 * 2. After successful deletion, fetches updated book list
 * 3. Displays refreshed book list using DisplayData component
 */
import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {useParams} from "react-router-dom";
//import { Link } from 'react-router-dom';
import DisplayData from './DisplayData';

export default function DeleteBook(props) {
    // State to store the list of books after deletion
    const [state, setState] = useState([]);
    
    // Get the book ID from URL parameters
    let params = useParams();

    /**
     * Effect hook that handles book deletion and list refresh
     * Triggers when component mounts or when book ID changes
     * 
     * Process:
     * 1. Sends DELETE request for specific book
     * 2. On success, fetches updated book list
     * 3. Updates state with new book list
     */
    useEffect(() => {
        console.log("useeff delete" + params.id)
        
        // First API call: Delete the book
        axios.post("http://localhost:5000/deleteBook/" + params.id)
            .then(res => {
                // Second API call: Get updated book list
                axios.get("http://localhost:5000/allbooks")
                    .then(res => {
                        // Update state with new book list
                        setState(res.data)
                        console.log("data set in the state and state length" + state.length)
                    })
                    .catch(err => {
                        console.log("error has occured")
                    })
            })
            .catch(err => {
                console.log("error has occured")
            })
    // Dependency array includes params.id to re-run effect if ID changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [params.id])

    /**
     * Render updated book list using DisplayData component
     * Books prop receives the current state containing all books
     */
    return (
        <div>
            <DisplayData Books={state}/>
        </div>
    )
}