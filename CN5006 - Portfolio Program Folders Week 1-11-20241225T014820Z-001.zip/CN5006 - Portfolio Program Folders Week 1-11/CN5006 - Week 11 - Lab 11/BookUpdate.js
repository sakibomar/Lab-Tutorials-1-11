import React, {useEffect, useState } from "react";
import axios from 'axios';
import {useParams } from "react-router-dom";

/**
 * BookUpdateForm - A React component for updating existing book information
 * 
 * This component provides a form interface for users to modify book details including:
 * - Book title
 * - Author information
 * - Topic/Category selection
 * - Format (Hard Copy or Electronic Copy)
 * - Publication Year
 * 
 * The component fetches existing book data using the book ID from URL parameters
 * and allows users to update the information through a form interface.
 */
function BookUpDateForm(props) {
  // Initialize form state with default values
  const [state, setState] = useState({
    booktitle: "",     // Stores the book's title
    author: "",        // Stores author name(s)
    formate: "",       // Stores book format (Hard/Electronic Copy)
    Topic: "",         // Stores book category/topic
    PubYear: 1990,     // Stores publication year with default value
  });

  // Backend API endpoint
  let url = "http://localhost:5000/"
  // Get URL parameters (book ID) using React Router
  let params = useParams();
 
  /**
   * Generic change handler for all form inputs
   * Updates the state while preserving other field values
   * 
   * @param {Object} e - Event object from form input change
   */
  const handleChange = (e) => {
    const value = e.target.value;
    setState({
      ...state,
      [e.target.name]: value,
    });
  };

  /**
   * Effect hook to fetch existing book data when component mounts
   * Makes API call to get book details based on URL parameter ID
   */
  useEffect(() => {
    axios.get('http://localhost:5000/getbook/' + params.id)
      .then(res => {
        // Update state with fetched book data
        console.log("update fun" + res.data)
        setState(res.data)
      })
      .catch(err => {
        console.log("error has occured")
      })
  // Dependency array left empty to run only on mount
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /**
   * Form submission handler for updating book information
   * Sends POST request to update endpoint with modified book data
   * 
   * @param {Object} e - Form submission event object
   */
  const OnSubmit = (e) => {
    e.preventDefault();
    
    // Create book data object from current state
    const bookdata = {
      booktitle: state.booktitle,
      PubYear: state.PubYear,
      author: state.author,
      Topic: state.Topic,
      formate: state.formate
    }
    
    // Make API call to update book data
    axios.post(url + "updatebook/" + params.id, bookdata)
      .then(res => console.log(res.data));
  }

  return (
    <div style={{marginTop: 10}}>
      <h3> Update Book Id: {state.booktitle}</h3>
      {/* Main form element with POST method */}
      <form onSubmit={OnSubmit} method="Post">
        {/* Book Title Input Section */}
        <div className="form-group"> 
          <label>Book Title: </label>
          <input  
            className="form-control" 
            type="text" 
            name="booktitle"
            value={state.booktitle}
            onChange={handleChange}
          />
        </div>

        {/* Book Authors Input Section */}
        <div className="form-group">
          <label>Book Authors: </label>
          <input  
            className="form-control" 
            name="author"
            value={state.author}
            onChange={handleChange}
          />
        </div>
        
        {/* Book Topic Dropdown Selection */}
        <div className="form-group">
          <label>
            Pick Book topic :{" "}
            <select 
              className="form-control" 
              name="Topic"
              value={state.Topic}
              onChange={handleChange}
            >
              {/* Predefined topic options */}
              <option value="Computer Science">Computer Science</option>
              <option value="Programming">Programming</option>
              <option value="Data Science">Data Sceince</option>
              <option value="AI">AI</option>
              <option value="Engineering">Engineering</option>
            </select>
          </label>
        </div>

        {/* Book Format Radio Button Selection */}
        <div className="form-group">
          <label>Formate: </label>
          {/* Hard Copy option */}
          <div className="form-check form-check-inline">
            <input 
              className="form-check-label"
              type="radio"
              name="formate"
              value="Hard Copy"
              checked={state.formate === "Hard Copy"}
              onChange={handleChange}
            />
            <label className="form-check-label"> Hard Copy </label>
          </div>
          {/* Electronic Copy option */}
          <div className="form-check form-check-inline">
            <input 
              className="form-check-label"
              type="radio"
              name="formate"
              value="Electronic Copy"
              checked={state.formate === "Electronic Copy"}
              onChange={handleChange}
            />
            <label className="form-check-label"> Electronic Copy</label>
          </div>
        </div>
        
        <br />
        <br />

        {/* Publication Year Range Slider */}
        <label>
          Publication Year (between 1980 and 2025):
          <input
            type="range"
            name="PubYear"
            min="1980"
            max="2025"
            value={state.PubYear}
            onChange={handleChange}
          />
        </label>

        {/* Form Submit Button */}
        <center>
          <div className="form-group">
            <input type="submit" value="UpDate" className="btn btn-primary" />
          </div>
        </center>            
      </form>
    </div>
  );
}

export default BookUpDateForm;