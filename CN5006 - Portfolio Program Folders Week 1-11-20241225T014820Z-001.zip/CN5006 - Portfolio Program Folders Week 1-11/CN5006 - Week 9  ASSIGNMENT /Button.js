/**
 * Button Component
 * Author: Saifullah: Omar
 * Date: 30/11/2024
 * ----------------
 * A stateless reusable button component for the calculator.
 * 
 * Features:
 * - Customizable via props: label, click handler, and CSS class.
 * - Simple structure ensures seamless integration and reusability.
 * 
 * Props:
 * - `label` (string): The text displayed on the button.
 * - `onClick` (function): Event handler triggered when the button is clicked.
 * - `className` (string): Optional custom CSS class for styling (defaults to "ButtonStyle").
 */
import React from "react";

const Button = ({ label, onClick, className = "ButtonStyle" }) => {
  return (
    <button className={className} onClick={onClick}>
      {label}
    </button>
  );
};

export default Button;
