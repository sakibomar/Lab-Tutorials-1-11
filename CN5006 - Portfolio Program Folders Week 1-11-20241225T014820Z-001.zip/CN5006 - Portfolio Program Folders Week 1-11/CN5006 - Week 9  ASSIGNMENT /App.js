import React from 'react';
import Calculator from './Calculator.js';

const App = () => {
  return (
    <div className="App">
      <Calculator />
    </div>
  );
};

export default App;
