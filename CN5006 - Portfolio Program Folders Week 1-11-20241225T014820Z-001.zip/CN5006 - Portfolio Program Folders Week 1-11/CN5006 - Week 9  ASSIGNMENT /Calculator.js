/**
 * Calculator Component - Calculator.js
 * Author: Saifullah Omar
 * Date: 30/11/2024
 * --------------------
 * Implements a fully functional calculator using React with modern hooks (`useState`, `useEffect`).
 * 
 * Functional Features:
 * - Performs basic arithmetic operations: addition, subtraction, multiplication, division.
 * - Supports clearing inputs (`C` and `CE`) and error management for invalid expressions.
 * - Provides advanced functionalities like squaring a number.
 * - Dynamically toggles a custom background image.
 * 
 * Core Design Considerations:
 * - Stateless `Button` components used for modularity and separation of concerns.
 * - State-driven UI for input/output (`text1`) and background image visibility (`showImage`).
 * - Clean separation of mathematical logic, UI state management, and side-effects (e.g., DOM manipulation).
 * 
 * Implementation Details:
 * - Mathematical expressions are evaluated using `eval` (a trade-off for simplicity vs. security; alternatives
 *   like math.js or custom parsers could enhance safety).
 * - Error states are explicitly handled to prevent application crashes during invalid evaluations.
 * - Dynamic DOM manipulation via `useEffect` ensures clean lifecycle management.
 */
import React, { useState, useEffect } from "react";
// Importing a reusable button component for the calculator
import Button from "./Button"; 
// Importing an image resource for dynamic background application
import IMAGE1 from './IMAGE1.png';
// Importing external CSS for component-specific styling
import './Calculator.css';

function Calculator() {
  // Manages the user's current input or the calculated result
  const [text1, setText] = useState("");

  // Manages the state of the background image visibility
  const [showImage, setShowImage] = useState(false);

  /**
   * Preprocesses the input expression to handle cases like missing multiplication operators
   * between numbers and parentheses (e.g., 3(3) should become 3*(3)).
   * 
   * @param {string} expression - The raw mathematical expression entered by the user.
   * @returns {string} - The corrected expression with necessary multiplication operators added.
   */
  const preprocessExpression = (expression) => {
    // Add '*' between numbers and parentheses if missing
    return expression
      .replace(/(\d)(\()/g, "$1*$2") // Number followed by '(' becomes 'number*('
      .replace(/(\))(\d)/g, "$1*$2"); // ')' followed by number becomes ') * number'
  };

  /**
   * Handles button click events for inputs and operations.
   * Supports both input construction and evaluation of expressions.
   * 
   * @param {string} e - The label of the button clicked, which determines the action.
   * 
   * Implementation Logic:
   * - `C`: Clears the entire input.
   * - `CE`: Removes the last character in the input.
   * - `=`: Evaluates the mathematical expression; handles errors with user-friendly feedback.
   * - Default Case: Appends the clicked button's value to the current input.
   */
  const ClickHandle = (e) => {
    switch (e) {
      case "C":
        // Completely resets the input
        setText(""); 
        break;
      case "CE":
        // Removes the last entered character
        setText((prevText) => prevText.slice(0, -1)); 
        break;
      case "=":
        try {
          // Preprocess the expression to add '*' where necessary
          const processedExpression = preprocessExpression(text1);
          // Evaluate the mathematical expression; output handled as a string for seamless updates
          setText(eval(processedExpression).toString());
        } catch (error) {
          // Sets "Error" for invalid mathematical expressions
          setText("Error"); 
        }
        break;
      default:
        // If the current state is an error, reset the state with the new input
        setText(text1 === "Error" ? e : text1 + e);
        break;
    }
  };

  /**
   * Toggles the visibility of the background image.
   * 
   * Implementation Detail:
   * - Uses a simple boolean toggle (`!showImage`) for switching states.
   */
  const handleShowMe = () => {
    setShowImage(!showImage);
  };

  /**
   * Squares the current input if it's a valid number.
   * Displays an error for invalid inputs (e.g., empty strings or non-numeric characters).
   * 
   * Implementation Logic:
   * - Validates the input using `parseFloat` and checks for `NaN`.
   * - If valid, calculates the square and updates the state; otherwise, sets the state to "Error".
   */
  const handleSquare = () => {
    // Converts input to a floating-point number
    const num = parseFloat(text1); 
    if (!isNaN(num)) {
      // Updates the state with the square of the number
      setText((num * num).toString());
    } else {
      // Sets error state for invalid inputs
      setText("Error"); 
    }
  };

  /**
   * Side-effect: Dynamically manages the `body` background image based on `showImage`.
   * 
   * Implementation Details:
   * - Applies a smooth transition effect for toggling the image.
   * - Cleanup function ensures the DOM is reset when the component unmounts.
   */
  useEffect(() => {
    // Conditionally set background image
    document.body.style.backgroundImage = showImage ? `url(${IMAGE1})` : ""; 
    // Ensures the image covers the entire viewport
    document.body.style.backgroundSize = "cover"; 
    // Center-aligns the image
    document.body.style.backgroundPosition = "center"; 
    // Smooth transition effect
    document.body.style.transition = "background 0.5s ease";
    return () => {
      // Cleanup on component unmount
      document.body.style.backgroundImage = ""; 
    };
  }, [showImage]); 

  return (
    <div className="Calculator">
      {/* Display Section: Shows the current input or result */}
      <div className="screen-row">
        <input type="text" readOnly value={text1} />
      </div>

      {/* Calculator Buttons: Grouped logically by type (operators, numbers, actions) */}
      <div>
        <Button label="(" onClick={() => ClickHandle("(")} />
        <Button label=")" onClick={() => ClickHandle(")")} />
        <Button label="CE" onClick={() => ClickHandle("CE")} />
        <Button label="C" onClick={() => ClickHandle("C")} />
      </div>
      <div>
        <Button label="1" onClick={() => ClickHandle("1")} />
        <Button label="2" onClick={() => ClickHandle("2")} />
        <Button label="3" onClick={() => ClickHandle("3")} />
        <Button label="+" onClick={() => ClickHandle("+")} />
      </div>
      <div>
        <Button label="4" onClick={() => ClickHandle("4")} />
        <Button label="5" onClick={() => ClickHandle("5")} />
        <Button label="6" onClick={() => ClickHandle("6")} />
        <Button label="-" onClick={() => ClickHandle("-")} />
      </div>
      <div>
        <Button label="7" onClick={() => ClickHandle("7")} />
        <Button label="8" onClick={() => ClickHandle("8")} />
        <Button label="9" onClick={() => ClickHandle("9")} />
        <Button label="*" onClick={() => ClickHandle("*")} />
      </div>
      <div>
        <Button label="." onClick={() => ClickHandle(".")} />
        <Button label="0" onClick={() => ClickHandle("0")} />
        <Button label="=" onClick={() => ClickHandle("=")} />
        <Button label="/" onClick={() => ClickHandle("/")} />
      </div>
      <div>
        <Button label="Show Me" onClick={handleShowMe} />
        <Button label="Square" onClick={handleSquare} />
      </div>
    </div>
  );
}

export default Calculator;
