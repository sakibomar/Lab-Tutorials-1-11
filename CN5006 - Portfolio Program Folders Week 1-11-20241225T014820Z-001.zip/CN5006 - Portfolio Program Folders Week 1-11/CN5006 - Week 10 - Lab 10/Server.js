/**
 * Book Management API Server
 * 
 * This module sets up an Express server that provides RESTful API endpoints
 * for managing a book collection. It includes operations for creating,
 * reading, updating, and deleting books, as well as retrieving all books
 * and getting information about the API.
 * 
 * @module Server
 */

const express = require("express")
const Books = require('./BooksScheme')   
const mongodbConnected = require('./MongoDBConnect')
const cors = require('cors')
const bodyParser = require("body-parser")

// Initialize Express application
const app = express()

// Middleware setup
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))
app.use(cors())

// Log the Books model for debugging purposes
console.log("BOOKS", Books)

/**
 * Root endpoint
 */
app.get('/', function(req, res) {
})

/**
 * About endpoint
 * Provides information about the API and counts the number of books in the database
 */
app.get('/about', function (req, res) { 
    res.send("MongoDB Express React and Mongoose app, React runs in another application")
    
    // Count and log the number of documents in the Books collection
    Books.countDocuments().exec() 
        .then(count => { 
            console.log("Total documents Count before addition:", count)  
        })
        .catch(err => { 
            console.error("Error counting documents:", err) 
        }) 
})

/**
 * Retrieve all books
 * @returns {Object[]} Array of book objects
 */
app.get('/allbooks', async (req, res) => {
    try {
        const books = await Books.find()
        res.status(200).json(books)
    } catch (error) {
        console.error("Error fetching all books:", error)
        res.status(500).json({ error: 'Internal Server Error' })
    }
})

/**
 * Retrieve a specific book by ID
 * @param {string} id - The ID of the book to retrieve
 * @returns {Object} The book object if found
 */
app.get('/getbook/:id', function(req, res) {
    const id = req.params.id
    Books.findById(id, function(err, book) {
        if (err) {
            console.error("Error fetching book:", err)
            return res.status(404).json({ error: 'Book not found' })
        }
        res.json(book)
    })
})

/**
 * Add a new book
 * @param {Object} req.body - The book object to add
 * @returns {Object} Confirmation message
 */
app.post('/addbooks', function(req, res) {
    console.log("Received book data:", req.body)
    const newBook = new Books(req.body)
    console.log("New book instance:", newBook)
    newBook.save()
        .then(book => {
            res.status(200).json({'books': 'Book added successfully'})
        })
        .catch(err => {
            console.error("Error adding new book:", err)
            res.status(400).send('Adding new book failed')
        })
})

/**
 * Update an existing book
 * @param {string} id - The ID of the book to update
 * @param {Object} req.body - The updated book data
 * @returns {Object} Confirmation message
 */
app.post('/updatebook/:id', function(req, res) {
    const id = req.params.id
    const updatedBook = new Books(req.body)
    console.log("Updating book:", id, "with data:", updatedBook)
    
    Books.findByIdAndUpdate(id, 
        {
            booktitle: updatedBook.booktitle,
            PubYear: updatedBook.PubYear,
            author: updatedBook.author,
            Topic: updatedBook.Topic,  
            formate: updatedBook.formate
        },  
        { new: true },
        function (err, docs) {  
            if (err) {  
                console.error("Error updating book:", err)
                return res.status(400).json({ error: 'Update failed' })
            }  
            res.status(200).json({'books': 'Book updated successfully'})
        }
    )
})

/**
 * Delete a book
 * @param {string} id - The ID of the book to delete
 * @returns {Object} Confirmation message
 */
app.post('/deleteBook/:id', function(req, res) {
    const id = req.params.id
    
    console.log("Deleting book:", id)
    Books.findByIdAndDelete(id, function (err, docs) {  
        if (err) {  
            console.error("Error deleting book:", err)
            return res.status(400).json({ error: 'Delete failed' })
        }  
        res.status(200).send('Book Deleted')
    })
})

// Start the server
const PORT = process.env.PORT || 5000
app.listen(PORT, function() {
    console.log(`Server is running on port ${PORT}`)
})


