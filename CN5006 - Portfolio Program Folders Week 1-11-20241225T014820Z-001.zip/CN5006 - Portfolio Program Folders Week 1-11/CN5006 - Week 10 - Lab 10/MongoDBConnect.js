/**
 * MongoDB Connection Module
 * 
 * This module establishes a connection to the MongoDB database
 * used by the Book Management API. It handles the connection
 * process and provides error handling and success logging.
 * 
 * @module MongoDBConnect
 */

const mongoose = require('mongoose')

/**
 * MongoDB connection URI
 */
const MONG_URI = 'mongodb://localhost:27017/lab_10'

/**
 * Establish connection to MongoDB
 */
mongoose.connect(MONG_URI, {
    useUnifiedTopology: true,
    useNewUrlParser: true,
})

/**
 * Get the default connection
 * @type {mongoose.Connection}
 */
const db = mongoose.connection

/**
 * Handle connection errors
 */
db.on('error', function(err) {
    console.error('MongoDB connection error:', err)
})

/**
 * Handle successful connection
 */
db.once('connected', function() {
    console.log('Successfully connected to MongoDB:', MONG_URI)
})

module.exports = db



