/**
 * Book Schema Definition
 * 
 * This module defines the schema for the Book model used in the
 * Book Management API. It specifies the structure and constraints
 * for book documents in the MongoDB database.
 * 
 * @module BooksScheme
 */

const mongoose = require('mongoose')

/**
 * Book Schema
 * @typedef {Object} BookScheme
 * @property {string} booktitle - The title of the book (required)
 * @property {number} PubYear - The publication year of the book
 * @property {string} author - The author of the book
 * @property {string} Topic - The main topic or genre of the book
 * @property {string} formate - The format of the book (e.g., hardcover, paperback, ebook)
 */
const BookScheme = new mongoose.Schema({
    booktitle: {
        type: String,
        required: true    
    },
    PubYear: Number,
    author: String,
    Topic: String,  
    formate: String
})

/**
 * Book Model
 * @type {mongoose.Model}
 */
module.exports = mongoose.model('bookmodel', BookScheme, 'BookCollection2')

