// mygreetingroup.js

// This functional component with propeties displays a message passed as a prop to the user on the web page.

// Author: Saifullah Omar
// Date: 30/10/2024

// Importing the CSS file to style the component
import './App.css';  

// Defining a functional component named GreetingElementwithProp that accepts props
function GreetingElementwithProp(props) {
    // Logging the value of the 'msg' prop to the console for debugging purposes
    console.log("prop is", props.msg);

    // Returning the JSX structure to be rendered
    return (
        <div className="App">  {/* A div container with the class "App" for styling */}
            <h1>{props.msg}</h1>  {/* Displaying the message passed as a prop inside an <h1> element */}
        </div>
    );
}

// Exporting the GreetingElementwithProp component for use in other files
export default GreetingElementwithProp;
