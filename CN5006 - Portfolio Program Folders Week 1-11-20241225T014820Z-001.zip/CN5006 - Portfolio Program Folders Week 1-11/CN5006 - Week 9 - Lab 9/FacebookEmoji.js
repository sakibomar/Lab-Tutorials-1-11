import './App.css' 
import React from 'react' 
import like7 from './like.png'; 
import Love from './Love.png'; 
import happy from './happy.png'; 
 
/**
 * FacebookEmojiCounter Component
 * 
 * This component creates a counter for different types of Facebook-style emoji reactions.
 * It's a flexible component that can be used for various emoji types (Love, Like, Happy).
 */
class FacebookEmojiCounter extends React.Component  
{ 
  /**
   * Constructor initializes the component's state, binds methods, and sets up the emoji image.
   * @param {Object} props - Component props, including the 'type' of emoji to display
   */
  constructor(props)  
  {  
    super(props); 
    // Initialize state with counter at 0
    this.state = {number : 0}; 
    // Bind the increment method
    this.increment = this.increment.bind(this); 
    // Determine which emoji image to use based on the 'type' prop
    this.pic = null 
    if (this.props.type === "Love") 
      this.pic = Love 
    else if (this.props.type === "Like")   
      this.pic = like7 
    else if (this.props.type === "happy")   
      this.pic = happy 
  } 
  
  /**
   * Increment method
   * Increases the counter by 1 using functional setState for reliability.
   */
  increment() { 
    this.setState((prevState) => ({
      number: prevState.number + 1
    }));
  } 

  /**
   * Render method
   * Displays the emoji counter and a button to increment it.
   * @returns {JSX.Element} Rendered component
   */
  render() { 
    return ( 
      <div> 
        <h5>It is {this.state.number} {this.props.type}.</h5> 
        <button onClick={this.increment}>   
          <img src={this.pic} alt={this.props.type} /> 
          <b>{this.state.number}</b> 
        </button>       
      </div> 
    ); 
  } 
} 
 
export default FacebookEmojiCounter;

