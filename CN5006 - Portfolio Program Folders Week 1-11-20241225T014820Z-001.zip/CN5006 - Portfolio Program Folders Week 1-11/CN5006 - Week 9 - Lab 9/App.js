import React from 'react';
import FacebookEmojiCounter from './FacebookEmoji';
import ToggleMode from './ToggleModeComponent';

/**
 * App Component
 * 
 * This is the main component of the React application.
 * It's implemented as a class component and renders the FacebookEmojiCounter
 * and ToggleMode components.
 */
class App extends React.Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <h1>React Emoji App</h1>
        </header>
        <main>
          <section className="emoji-counters">
            <FacebookEmojiCounter type="Like" />
            <FacebookEmojiCounter type="Love" />
            <FacebookEmojiCounter type="happy" />
          </section>
          <section className="mood-toggle">
            <ToggleMode />
          </section>
        </main>
      </div>
    );
  }
}

export default App;

