import './App.css';
import React from 'react';

import sad from './sad.png';
import happy from './happy.png';

/**
 * ToggleMode Component
 * 
 * This component implements a toggle functionality between happy and sad moods.
 * It uses class-based React component structure with state management.
 */
class ToggleMode extends React.Component {
  /**
   * Constructor initializes the component's state and binds methods.
   * @param {Object} props - Component props (unused in this implementation)
   */
  constructor(props) {
    super(props);
    // Initialize state with happy mood as default
    this.state = {
      pic: happy,
      mode: "happy" 
    };
    // Bind the Toggle_Mode method to ensure 'this' refers to the component instance
    this.Toggle_Mode = this.Toggle_Mode.bind(this);
  }

  /**
   * Toggle_Mode method
   * Switches the mood between happy and sad, updating both the image and the mode text.
   * Uses functional setState to ensure state updates are based on the previous state.
   */
  Toggle_Mode() {
    this.setState((prevState) => {
      // Toggle between sad and happy moods
      if (prevState.pic === sad) {
        return { pic: happy, mode: "happy" }; 
      } else if (prevState.pic === happy) {
        return { pic: sad, mode: "sad" }; 
      }
    });
  }

  /**
   * Render method
   * Displays the current mood and a button to toggle it.
   * @returns {JSX.Element} Rendered component
   */
  render() {
    return (
      <div>
        <h3>This is output of Task 2: {this.state.mode}</h3>
        <button onClick={this.Toggle_Mode}>
          <img src={this.state.pic} alt="mood" />
        </button>
      </div>
    );
  }
}

export default ToggleMode;

