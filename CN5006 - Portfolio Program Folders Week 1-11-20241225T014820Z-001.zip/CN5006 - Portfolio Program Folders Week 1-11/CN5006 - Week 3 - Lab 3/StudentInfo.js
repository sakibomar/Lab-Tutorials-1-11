/**
 * StudentInfo.js
 *
 * This module provides student-related information and functions to retrieve details like 
 * name, campus location, date of birth, and grade based on marks.
 *
 * The module exports the following:
 * 
 * - `getName`: Returns a placeholder student name.
 * - `getLocation`: Returns a placeholder campus location.
 * - `dob`: A constant holding the student's date of birth.
 * - `getStudentGrade`: A function that accepts marks as a parameter and returns a grade:
 *    - Returns "B grade" for marks between 51 and 69.
 *    - Returns "A grade" for marks outside this range.
 * 
 * This module is used in the main program to provide student information, which helps 
 * demonstrate how data can be fetched and displayed from an external source.
 * 
 * @see index.js
 * 
 * @author Saifullah Omar
 * 
 * @version 16/10/24
 */

// Define a constant variable for the student's date of birth
const studentDOB = "10/13/1980";

// Define a function to return a placeholder student name
const fetchStudentName = () => 
{
    return "David The Code Master";
};

// Define a function to return the campus name
const fetchCampusName = () => 
{
    return "UEL Campus";
};

// Exporting functions and variable outside the module
exports.getName = fetchStudentName;
exports.getLocation = fetchCampusName;
exports.dob = studentDOB;

// Export a function that takes a parameter (marks) and returns a grade based on its value
exports.getStudentGrade = (marks) => 
{
    if (marks > 50 && marks < 70) 
    {
        return "B grade";
    } 
    else 
    {
        return "A grade";
    }
};
