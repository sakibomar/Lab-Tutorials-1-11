/**
 * Exercise4.js
 *
 * This application logs essential system information such as temporary directory, hostname, 
 * operating system platform and release, system uptime, user information, memory statistics, 
 * CPU details, and network interfaces. 
 *
 * It uses the Node.js "os" module to retrieve system-level information, and the "util" module 
 * to format some of this data for easier reading. Specifically, the program outputs the 
 * following:
 * 
 * - Temporary directory path
 * - Hostname of the machine
 * - Operating system platform and release version
 * - System uptime in hours
 * - User information, including username and home directory
 * - Total and free memory in gigabytes
 * - Detailed CPU information, including model and speed of each core
 * - Network interfaces, showing IP addresses and other details
 * 
 * This program provides a quick overview of the current system's environment and resources, 
 * which can be useful for diagnostic purposes or for monitoring system status.
 * 
 * @author Saifullah
 * 
 * @version 13/10/2024
 */

// Import required modules
const os = require("os");
const util = require('util');

// Log essential system information
console.log("Temporary Directory: " + os.tmpdir());
console.log("Hostname: " + os.hostname());
console.log("OS: " + os.platform() + ", Release: " + os.release());
console.log("Uptime: " + (os.uptime() / 3600).toFixed(2) + " hours");
console.log("User Info: " + util.inspect(os.userInfo()));
console.log("Total Memory: " + (os.totalmem() / 1e9).toFixed(2) + " GigaBytes");
console.log("Free Memory: " + (os.freemem() / 1e9).toFixed(2) + " GigaBytes");

// Log CPU information
console.log("CPU Info: " + util.inspect(os.cpus()));

// Log network interfaces information
console.log("Network Interfaces: " + util.inspect(os.networkInterfaces()));

// End of the program
console.log("Program ended");
